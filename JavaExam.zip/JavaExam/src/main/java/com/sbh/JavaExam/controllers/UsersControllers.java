package com.sbh.JavaExam.controllers;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.sbh.JavaExam.models.Idea;
import com.sbh.JavaExam.models.User;
import com.sbh.JavaExam.models.User_Ideas;
import com.sbh.JavaExam.services.UserService;
import com.sbh.JavaExam.validation.UserValidator;

@Controller
public class UsersControllers {
	
	private final UserService userService;
	private final UserValidator userValidator;

    
    public UsersControllers (UserService userService, UserValidator userValidator) {
        this.userService = userService;
        this.userValidator=  userValidator;
    }
	    
    	@GetMapping("/")
    	public String register() {
    		return "redirect:/registration";
    	}
    
    
	    @RequestMapping("/registration")
	    public String registerForm(@ModelAttribute("user") User user) {
	        return "registrationPage.jsp";
	    }
	    
//	    @RequestMapping("/login")
//	    public String login() {
//	        return "homePage.jsp";
//	    }
	    
	    @RequestMapping(value="/registration", method=RequestMethod.POST)
	    public String registerUser(@Valid @ModelAttribute("user") User user, BindingResult result, HttpSession session) {
	    	System.out.println("**************");
	    	System.out.println(user.getEmail());
	    	System.out.println("**************");
//	    	System.out.println(this.userService.findByEmail(user.getEmail()).toString());
	    	userValidator.validate(user, result);
	    	if(result.hasErrors()) {
	    		return "registrationPage.jsp";
	    	}
//			this.userService.registerUser(user);
			User u = this.userService.registerUser(user);
			session.setAttribute("userid", u.getId());
			return "redirect:/homePage";
		}
	    
	    @GetMapping("/homePage")
	    public String homePage (Model model, HttpSession session) {
	    	Long id = (Long)session.getAttribute("userid");
	    	User loggedin = this.userService.findUserById(id);
	    	model.addAttribute("user", loggedin);
	    	model.addAttribute("allideas",this.userService.findAllIdeas());
	    	return "homePage.jsp";
	    	
	    }
	    
	    @GetMapping("/logout")
	    public String logout (HttpSession session) {
	    	session.invalidate();
	    	return "redirect:/registration";
	    }
	    	
	    
  
	    @PostMapping("/login")
	    public String login (@RequestParam ("email")String email, @RequestParam("password") String Password, HttpSession session, RedirectAttributes redirectAttributes) {
	    	Boolean isGood = userService.authenticateUser(email, Password);
	    	if(isGood) {
	    		User user = userService.findByEmail(email);
	    		session.setAttribute("userid",user.getId());
	    		return "redirect:/homePage";
	    	}
	    	
	    	redirectAttributes.addFlashAttribute("error", "Invalid login attempt. Please re-enter information");	
	    	return "redirect:/registration";
	    	}
//	    
	    
	    @GetMapping("/ideas/new")
	    public String createIdea(@ModelAttribute("idea")Idea idea, BindingResult result, Model model, HttpSession session) {
	    	Long id = (Long)session.getAttribute("userid");
	    	User loggedin = this.userService.findUserById(id);
	    	model.addAttribute("user", loggedin);
	    	return "createIdea.jsp";
	    }
	    
	    @PostMapping("/ideas/create")
	    public String makeIdea(@Valid @ModelAttribute("idea")Idea idea, BindingResult result, Model model, HttpSession session) {
	    	if(result.hasErrors()) {
	    		return "redirect:/ideas/new";
	    	}
	    	
	    	Long id = (Long)session.getAttribute("userid");
	    	User loggedinuser = this.userService.findUserById(id);
	    	model.addAttribute("user", loggedinuser);
	    	
	    	idea.setCreator(loggedinuser);
	    	
	    	userService.createIdea(idea);
	    	
	    	return "redirect:/homePage";
	    }
	    
	    
	    @RequestMapping("ideas/{id}")
	    	public String showIdea (@PathVariable("id")Long id, Model model) {
	    	
	    	model.addAttribute("idea", this.userService.findAnIdea(id));
	    	model.addAttribute("user", this.userService.findUserById(id));
	    	return "showIdea.jsp";
	    }
	    
	    
	    @RequestMapping("/ideas/{id}/edit")
	    	public String editIdea (@PathVariable("id")Long id, Model model) {
	    	model.addAttribute("idea", this.userService.findAnIdea(id));
	    	model.addAttribute("user", this.userService.findUserById(id));
	    	return "editIdea.jsp";
	    }
	    
	    @RequestMapping(value="/ideas/{id}/update", method=RequestMethod.POST)
	    	public String updateIdea (@Valid @ModelAttribute("idea") Idea idea, BindingResult result, @PathVariable("id") Long id, HttpSession session) {
	    		idea.setId(id);
	    		if(result.hasErrors()) {
	    			return "editIdea.jsp";
	    		} else {;
	    			
	    	    	Long loggedinuserid = (Long)session.getAttribute("userid");
	    	    	User loggedinuser = this.userService.findUserById(loggedinuserid);
	    			
	    	    	idea.setCreator(loggedinuser);
	    			this.userService.updateIdea(idea);
	    			return "redirect:/homePage";
	    		}
	    }
	    
	    
	    @RequestMapping(value="/ideas/{id}/delete")
	    public String destroyIdea (@PathVariable("id") Long id) {
	    	userService.deleteIdea(id);
	    	return "redirect:/homePage";
	    }
	    
	    @GetMapping("/like/{id}")
	    public String likeIdea(@PathVariable("id")Long id, HttpSession session) {
	    	///get the group from path variable
	    	Idea i = this.userService.findAnIdea(id);
	    	
	    	
	    	///get the logged in user
	    	Long loggedinuserid = (Long)session.getAttribute("userid");
	    	User loggedinuser = this.userService.findUserById(loggedinuserid);
	    	
	    	/// if the logged in user is already a member just redirect
	    	if(i.getMembers().contains(loggedinuser)) {
	    		return "redirect:/";
	    	}
	    	
	    	
	    	//create an object that you can save to the many table by calling on the constructor on the many to many table
	    	User_Ideas user_ideas = new User_Ideas (loggedinuser,i);
	    	
	    	//save this to the third table
	    	this.userService.createAssociation(user_ideas);
	    	
	    	
	    	return "redirect:/homePage";
	    	
	    }
	    
	    
	    
//	    @RequestMapping("/home")
//	    public String home(HttpSession session, Model model) {
//	    	Long userId = (Long) session.getAttribute("userId");
//	    	User u = userService.findUserById(userId);
//	    	model.addAttribute("user", u);
//	    	return "homePage.jsp";
//	    }
//	    
//	    
//	    @RequestMapping("/logout")
//	    public String logout(HttpSession session) {
//// invalidate session
//// redirect to login page
//	    }
}    
	

