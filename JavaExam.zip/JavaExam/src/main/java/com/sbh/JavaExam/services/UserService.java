package com.sbh.JavaExam.services;

import java.util.List;

import org.mindrot.jbcrypt.BCrypt;
import org.springframework.stereotype.Service;

import com.sbh.BeltReviewer.models.UserGroupMembers;
import com.sbh.JavaExam.models.Idea;
import com.sbh.JavaExam.models.User;
import com.sbh.JavaExam.models.User_Ideas;
import com.sbh.JavaExam.respositories.UserRepository;
import com.sbh.JavaExam.respositories.User_IdeasRepository;
import com.sbh.JavaExam.respositories.IdeaRepository;



@Service
public class UserService {

	//    private final UserRepository userRepo;
    
    private UserRepository UserRepository;
    private IdeaRepository IdeaRespository;
	private User_IdeasRepository User_IdeasRepository;

	public UserService(UserRepository userRepository,IdeaRepository ideaRespository, User_IdeasRepository userRespository) {
        this.UserRepository = userRepository;
        this.IdeaRespository= ideaRespository;
        this.User_IdeasRepository = userRespository;
    }
    
// register user and hash their password
    public User registerUser(User user) {
        String hashed = BCrypt.hashpw(user.getPassword(), BCrypt.gensalt());
        user.setPassword(hashed);
        user.setEmail(user.getEmail().toLowerCase());
        return UserRepository.save(user);
 
    }

// find user by email
	public User findByEmail(String email) {
        return UserRepository.findByEmail(email);
    }
    
// find user by id
    public User findUserById(Long id) {
//    	Optional<User> u = userRepo.findById(id);
//    	
//    	if(u.isPresent()) {
//            return u.get();
//    	} else {
//    	    return null;
//    	}
    return UserRepository.findById(id).orElse(null);
   
    }
    
    public User getPassword (Long id) {
    	return this.UserRepository.findById(id).orElse(null);
    }
    
    public User setPassword (User password) {
    	return this.UserRepository.save(password);
    	
    }

    public boolean authenticateUser (String email,String password) {
    	User user = this.UserRepository.findByEmail(email);
    	if (user==null) {
    		return false;
    	} else {
    		if (BCrypt.checkpw(password, user.getPassword())) {
    			return true;
    		}
    		else {
    			return false;
    	
    			
    		}
    	}
	}

    public List<User> findAllUsers(){
    	return(List<User>)this.UserRepository.findAll();
    }

    public Idea createIdea (Idea idea) {
    	return this.IdeaRespository.save(idea);
    	}
    
    public List<Idea>findAllIdeas(){
    	return (List<Idea>)this.IdeaRespository.findAll();
    	}
    
    public Idea findAnIdea (Long id) {
    	return this.IdeaRespository.findById(id).orElse(null);
    }
    

////    
    public Idea updateIdea(Idea idea) {
    	return this.IdeaRespository.save(idea);
    }
    
    public void deleteIdea (Long id) {
    	this.IdeaRespository.deleteById(id);
    }

    public User_Ideas createAssociation (User_Ideas ud) {
		return this.User_IdeasRepository.save(ud);
	}

    

}



    
    
    
    