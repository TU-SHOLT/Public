package com.sbh.JavaExam.respositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.sbh.JavaExam.models.User;
import com.sbh.JavaExam.models.User_Ideas;

@Repository
public interface User_IdeasRepository extends CrudRepository<User_Ideas, Long> {
	List<User_Ideas>findAll();
}
